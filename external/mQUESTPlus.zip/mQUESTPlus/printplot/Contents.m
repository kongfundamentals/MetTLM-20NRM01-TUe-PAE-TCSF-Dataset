% mQUESTPlus - printplot
%
% Support for printing and plotting.  Well, no plotting yet.
%
% qpPrintParams                 - Print out a parameters vector.
% qpPrintStim                   - Print out stimulus vector.
% qpPrintStimCounts             - Print out stimulus count data array.
% qpPrintStimData               - Print out stimulus data array.
% qpPrintStimProportions        - Print out stimulus proportions data array.
% qpPrintTrialData              - Print out trial data array. 
